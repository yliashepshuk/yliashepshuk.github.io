/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-picture': '&#xe906;',
		'icon-photos': '&#xe906;',
		'icon-images': '&#xe906;',
		'icon-download': '&#xe904;',
		'icon-home3': '&#xe903;',
		'icon-music': '&#xe911;',
		'icon-film': '&#xe913;',
		'icon-user': '&#xe971;',
		'icon-cogs': '&#xe995;',
		'icon-facebook': '&#xea90;',
		'icon-twitter': '&#xea96;',
		'icon-rss': '&#xea9b;',
		'icon-steam2': '&#xeaad;',
		'icon-appleinc': '&#xeabe;',
		'icon-windows8': '&#xeac2;',
		'icon-skype': '&#xeac5;',
		'icon-chrome': '&#xead9;',
		'icon-IE': '&#xeadb;',
		'icon-safari': '&#xeadd;',
		'icon-opera': '&#xeade;',
		'icon-html-five': '&#xeae4;',
		'icon-css3': '&#xeae6;',
		'icon-pinterest-square': '&#xe901;',
		'icon-github-alt': '&#xe902;',
		'icon-google': '&#xe900;',
		'icon-mozillafirefox': '&#x1f320;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
